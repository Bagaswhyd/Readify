package com.rplkematian.readify.di.modules

import com.rplkematian.readify.data.repository.BooksRepositoryImpl
import com.rplkematian.readify.data.repository.LibraryRepositoryImpl
import com.rplkematian.readify.data.repository.UserPreferencesRepositoryImpl
import com.rplkematian.readify.domain.repository.BooksRepository
import com.rplkematian.readify.domain.repository.LibraryRepository
import com.rplkematian.readify.domain.repository.UserPreferencesRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindBooksRepository(
        booksRepositoryImpl: BooksRepositoryImpl
    ): BooksRepository

    @Binds
    @Singleton
    abstract fun bindLibraryRepository(
        libraryRepositoryImpl: LibraryRepositoryImpl
    ): LibraryRepository

    @Binds
    @Singleton
    abstract fun bindUserPreferencesRepository(
        userPreferencesRepositoryImpl: UserPreferencesRepositoryImpl
    ): UserPreferencesRepository
}