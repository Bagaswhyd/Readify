package com.rplkematian.readify

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rplkematian.readify.domain.repository.UserPreferencesRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.runBlocking

class MainViewModel(
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {

    val hasCompletedQuestionnaire = runBlocking {
        userPreferencesRepository.userPreferences
            .map { it.hasCompletedQuestionnaire }
    }
}