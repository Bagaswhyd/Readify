package com.rplkematian.readify.presentation.screens.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rplkematian.readify.domain.models.Book
import com.rplkematian.readify.domain.repository.LibraryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

class LibraryViewModel (
    private val libraryRepository: LibraryRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val searchQuery = _searchQuery.asStateFlow()

    private val _uiState = MutableStateFlow(LibraryUiState())
    val uiState: StateFlow<LibraryUiState> = combine(
        searchQuery,
        libraryRepository.getAllBooks()
    ) { query, books ->
        LibraryUiState(
            books = if (query.isEmpty()) {
                books
            } else {
                books.filter { book ->
                    book.title.contains(query, ignoreCase = true) ||
                            book.authors.any { it.contains(query, ignoreCase = true) }
                }
            },
            searchQuery = query
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LibraryUiState()
    )

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun removeBook(bookId: String) {
        viewModelScope.launch {
            try {
                libraryRepository.removeBook(bookId)
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
}

data class LibraryUiState(
    val books: List<Book> = emptyList(),
    val searchQuery: String = ""
)