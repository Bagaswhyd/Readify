package com.rplkematian.readify.data.local.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

@Entity(tableName = "library_books")
@TypeConverters(StringListConverter::class)
data class LibraryBookEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val authors: List<String>,
    val description: String?,
    val coverUrl: String?,
    val categories: List<String>,
    val rating: Double?,
    val ratingCount: Int?,
    val pageCount: Int?,
    val publishedDate: String?,
    val publisher: String?,
    val language: String?,
    val buyLink: String?,
    val webReaderLink: String?,
    val addedAt: Long = System.currentTimeMillis()
)

class StringListConverter {
    private val gson = Gson()

    @TypeConverter
    fun fromString(value: String?): List<String> {
        if (value == null) return emptyList()
        val listType = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(value, listType)
    }

    @TypeConverter
    fun toString(list: List<String>): String {
        return gson.toJson(list)
    }
}