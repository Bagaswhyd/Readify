package com.rplkematian.readify.data.local.database.dao

import androidx.room.*
import com.rplkematian.readify.data.local.database.entity.LibraryBookEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LibraryDao {
    @Query("SELECT * FROM library_books ORDER BY addedAt DESC")
    fun getAllBooks(): Flow<List<LibraryBookEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBook(book: LibraryBookEntity)

    @Delete
    suspend fun deleteBook(book: LibraryBookEntity)

    @Query("DELETE FROM library_books WHERE id = :bookId")
    suspend fun deleteBookById(bookId: String)

    @Query("SELECT * FROM library_books WHERE id = :bookId")
    fun isBookInLibrary(bookId: String): Flow<List<LibraryBookEntity>>

    @Query("SELECT * FROM library_books WHERE id = :bookId")
    suspend fun getBookById(bookId: String): LibraryBookEntity?

    @Query("SELECT * FROM library_books WHERE title LIKE '%' || :query || '%' OR :query = ''")
    fun searchBooks(query: String): Flow<List<LibraryBookEntity>>
}