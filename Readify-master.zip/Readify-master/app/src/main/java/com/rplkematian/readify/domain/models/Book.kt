package com.rplkematian.readify.domain.models

data class Book(
    val id: String,
    val title: String,
    val authors: List<String>,
    val description: String?,
    val coverUrl: String?,
    val categories: List<String>,
    val rating: Double?,
    val ratingCount: Int?,
    val pageCount: Int?,
    val publishedDate: String?,
    val publisher: String?,
    val language: String?,
    val buyLink: String?,
    val webReaderLink: String?
)