package com.rplkematian.readify.utils

import android.content.Context
import com.google.gson.Gson
import com.rplkematian.readify.BuildConfig
import com.rplkematian.readify.data.api.GoogleBooksApi
import com.rplkematian.readify.data.api.GoogleBooksApiClient
import com.rplkematian.readify.data.local.database.ReadifyDatabase
import com.rplkematian.readify.data.repository.BooksRepositoryImpl
import com.rplkematian.readify.data.repository.LibraryRepositoryImpl
import com.rplkematian.readify.data.repository.UserPreferencesRepositoryImpl
import com.rplkematian.readify.di.modules.NetworkModule
import com.rplkematian.readify.domain.repository.BooksRepository
import com.rplkematian.readify.domain.repository.LibraryRepository
import com.rplkematian.readify.domain.repository.UserPreferencesRepository

object Injection {
    fun provideBooksRepository(context: Context): BooksRepository {
        val retrofit = NetworkModule.provideRetrofit(NetworkModule.provideOkHttpClient())
        val api = retrofit.create(GoogleBooksApi::class.java)
        val apiClient = GoogleBooksApiClient(api, BuildConfig.BOOKS_API_KEY)
        return BooksRepositoryImpl(apiClient)
    }

    fun provideLibraryRepository(context: Context): LibraryRepository {
        val db = ReadifyDatabase.getInstance(context)
        val dao = db.libraryDao()
        return LibraryRepositoryImpl(dao)
    }

    fun provideUserPreferencesRepository(context: Context): UserPreferencesRepository {
        return UserPreferencesRepositoryImpl(context.applicationContext, Gson())
    }
}