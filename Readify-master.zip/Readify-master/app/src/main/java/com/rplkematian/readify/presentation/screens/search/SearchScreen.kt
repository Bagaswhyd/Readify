package com.rplkematian.readify.presentation.screens.search

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rplkematian.readify.R
import com.rplkematian.readify.presentation.screens.search.components.GenreGrid
import com.rplkematian.readify.presentation.screens.search.components.SearchBar
import com.rplkematian.readify.presentation.screens.search.components.SearchResultItem
import com.rplkematian.readify.utils.ViewModelFactory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    onBookClick: (String) -> Unit,
    viewModel: SearchViewModel = viewModel(factory = ViewModelFactory.getInstance(LocalContext.current))
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = Modifier,
        topBar = {
            TopAppBar(
                title = { Text("Search") }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            SearchBar(
                query = uiState.searchQuery,
                onQueryChange = viewModel::onSearchQueryChange,
                onSearch = viewModel::search,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )

            when {
                uiState.isLoading -> {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        CircularProgressIndicator()
                        Log.d("Search screen", "isLoading")
                    }
                }

                uiState.error != null -> {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Text(
                            text = uiState.error ?: stringResource(R.string.error_searching_books),
                            color = MaterialTheme.colorScheme.error
                        )
                        Log.d("Search screen", "error")
                    }
                }

                uiState.searchResults.isEmpty() -> {
                    GenreGrid(
                        genres = uiState.genres,
                        onGenreClick = { selectedGenre ->
                            viewModel.onGenreSelected(selectedGenre)
                            Log.d("Genre clicked", selectedGenre)
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                else -> {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(16.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(uiState.searchResults) { book ->
                            SearchResultItem(
                                book = book,
                                onClick = { onBookClick(book.id) }
                            )
                            Log.d("Search screen", "success")
                        }
                    }
                }
            }
        }
    }
}