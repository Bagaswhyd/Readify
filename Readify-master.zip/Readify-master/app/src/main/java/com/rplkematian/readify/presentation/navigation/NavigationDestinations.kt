package com.rplkematian.readify.presentation.navigation

sealed class Screen(val route: String) {
    data object Browse : Screen("browse")
    data object Search : Screen("search")
    data object Library : Screen("library")
    data object BookDetail : Screen("book_detail/{bookId}") {
        fun createRoute(bookId: String) = "book_detail/$bookId"
    }
    data object Questionnaire : Screen("questionnaire")
}