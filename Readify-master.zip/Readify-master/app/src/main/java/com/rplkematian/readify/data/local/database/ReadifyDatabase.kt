package com.rplkematian.readify.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.rplkematian.readify.data.local.database.dao.LibraryDao
import com.rplkematian.readify.data.local.database.entity.LibraryBookEntity
import com.rplkematian.readify.data.local.database.entity.StringListConverter

@Database(
    entities = [LibraryBookEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(StringListConverter::class)
abstract class ReadifyDatabase : RoomDatabase() {
    abstract fun libraryDao(): LibraryDao

    companion object {
        @Volatile
        private var INSTANCE: ReadifyDatabase? = null
        fun getInstance(context: Context): ReadifyDatabase {
             if (INSTANCE == null) {
                 synchronized(this) {
                     INSTANCE = Room.databaseBuilder(
                         context.applicationContext,
                         ReadifyDatabase::class.java,
                         "readify_database"
                     ).build()
                 }
             }
            return INSTANCE as ReadifyDatabase
        }
    }
}