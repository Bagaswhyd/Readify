package com.rplkematian.readify.presentation.screens.questionnaire

val AVAILABLE_GENRES = listOf(
    "Fiction",
    "Mystery",
    "Science Fiction",
    "Fantasy",
    "Romance",
    "Thriller",
    "Horror",
    "Biography",
    "History",
    "Science",
    "Philosophy",
    "Poetry",
    "Self-Help",
    "Business",
    "Comics",
    "Art",
    "Cooking",
    "Travel"
)