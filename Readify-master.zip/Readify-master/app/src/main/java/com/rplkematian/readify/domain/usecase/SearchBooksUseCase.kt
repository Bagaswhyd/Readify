package com.rplkematian.readify.domain.usecase

import com.rplkematian.readify.domain.models.Book
import com.rplkematian.readify.domain.repository.BooksRepository
import javax.inject.Inject

class SearchBooksUseCase @Inject constructor(
    private val repository: BooksRepository
) {
    suspend operator fun invoke(query: String, page: Int = 0): Result<List<Book>> {
        return if (query.isBlank()) {
            Result.success(emptyList())
        } else {
            repository.searchBooks(query, page)
        }
    }
}