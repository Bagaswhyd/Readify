package com.rplkematian.readify.domain.repository

import com.rplkematian.readify.data.local.database.entity.LibraryBookEntity
import com.rplkematian.readify.domain.models.Book
import kotlinx.coroutines.flow.Flow

interface LibraryRepository {
    fun getAllBooks(): Flow<List<Book>>
    suspend fun addBook(book: Book)
    suspend fun removeBook(bookId: String)
    fun isBookInLibrary(bookId: String): Flow<List<LibraryBookEntity>>
    fun searchBooks(query: String): Flow<List<Book>>
    suspend fun getBookById(bookId: String): LibraryBookEntity?
}