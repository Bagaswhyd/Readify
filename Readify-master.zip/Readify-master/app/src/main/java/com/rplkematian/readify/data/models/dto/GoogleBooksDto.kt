package com.rplkematian.readify.data.models.dto

import com.google.gson.annotations.SerializedName

data class GoogleBooksResponse(
    val items: List<BookDto>?,
    val totalItems: Int,
    val kind: String
)

data class BookDto(
    val id: String,
    val volumeInfo: VolumeInfoDto,
    val saleInfo: SaleInfoDto?,
    val accessInfo: AccessInfoDto?
)

data class VolumeInfoDto(
    val title: String,
    val authors: List<String>?,
    val publisher: String?,
    @SerializedName("publishedDate")
    val publishedDate: String?,
    val description: String?,
    val pageCount: Int?,
    val categories: List<String>?,
    val imageLinks: ImageLinksDto?,
    val language: String?,
    val averageRating: Double?,
    val ratingsCount: Int?
)

data class ImageLinksDto(
    val smallThumbnail: String?,
    val thumbnail: String?,
    val small: String?,
    val medium: String?,
    val large: String?,
    val extraLarge: String?
)

data class SaleInfoDto(
    val buyLink: String?,
    val isEbook: Boolean
)

data class AccessInfoDto(
    val webReaderLink: String?,
    val accessViewStatus: String?
)