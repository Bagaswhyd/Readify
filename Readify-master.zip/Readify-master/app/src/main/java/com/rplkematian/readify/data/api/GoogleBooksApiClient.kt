package com.rplkematian.readify.data.api

import com.rplkematian.readify.data.models.dto.BookDto
import com.rplkematian.readify.data.models.dto.GoogleBooksResponse
import javax.inject.Inject

class GoogleBooksApiClient @Inject constructor(
    private val api: GoogleBooksApi,
    private val apiKey: String
) {
    suspend fun searchBooks(
        query: String,
        startIndex: Int = 0,
        maxResults: Int = 20,
        orderBy: String = "relevance",
        filter: String = "paid-ebooks",
        langRestrict: String = "en",
        printType: String = "books"
    ): GoogleBooksResponse {
        val fullQuery = when {
            query.startsWith("subject:") -> query
            else -> query
        }

        return api.searchBooks(
            query = fullQuery,
            startIndex = startIndex,
            maxResults = maxResults,
            orderBy = orderBy,
            filter = filter,
            langRestrict = langRestrict,
            printType = printType,
            apiKey = apiKey
        )
    }

    suspend fun getBookDetails(volumeId: String): BookDto {
        return api.getBookDetails(volumeId, apiKey)
    }

    // Helper functions for common search types
    suspend fun searchPopularBooks(maxResults: Int = 20): GoogleBooksResponse {
        return searchBooks(
            query = "subject:fiction",
            maxResults = maxResults,
            orderBy = "relevance",
            filter = "paid-ebooks"
        )
    }

    suspend fun searchBooksByGenre(genre: String, maxResults: Int = 20): GoogleBooksResponse {
        return searchBooks(
            query = "subject:$genre",
            maxResults = maxResults,
            orderBy = "relevance",
            filter = "paid-ebooks"
        )
    }

    suspend fun searchNewReleases(maxResults: Int = 20): GoogleBooksResponse {
        return searchBooks(
            query = "subject:fiction",
            maxResults = maxResults,
            orderBy = "newest",
            filter = "paid-ebooks"
        )
    }
}