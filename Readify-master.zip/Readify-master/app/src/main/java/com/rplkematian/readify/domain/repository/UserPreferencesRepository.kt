package com.rplkematian.readify.domain.repository

import com.rplkematian.readify.domain.models.UserPreferences
import kotlinx.coroutines.flow.Flow

interface UserPreferencesRepository {
    val userPreferences: Flow<UserPreferences>
    suspend fun updateUserPreferences(userPreferences: UserPreferences)
}