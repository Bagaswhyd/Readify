package com.rplkematian.readify.utils

import android.content.Context
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.rplkematian.readify.MainViewModel
import com.rplkematian.readify.domain.repository.BooksRepository
import com.rplkematian.readify.domain.repository.LibraryRepository
import com.rplkematian.readify.domain.repository.UserPreferencesRepository
import com.rplkematian.readify.presentation.screens.bookdetail.BookDetailViewModel
import com.rplkematian.readify.presentation.screens.browse.BrowseViewModel
import com.rplkematian.readify.presentation.screens.library.LibraryViewModel
import com.rplkematian.readify.presentation.screens.questionnaire.QuestionnaireViewModel
import com.rplkematian.readify.presentation.screens.search.SearchViewModel

class ViewModelFactory private constructor(
    private val booksRepository: BooksRepository,
    private val libraryRepository: LibraryRepository,
    private val userPreferencesRepository: UserPreferencesRepository,
    private val savedStateHandle: SavedStateHandle
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                MainViewModel(userPreferencesRepository) as T
            }
            modelClass.isAssignableFrom(BookDetailViewModel::class.java) -> {
                BookDetailViewModel(booksRepository, libraryRepository, savedStateHandle) as T
            }
            modelClass.isAssignableFrom(BrowseViewModel::class.java) -> {
                BrowseViewModel(booksRepository, userPreferencesRepository) as T
            }
            modelClass.isAssignableFrom(LibraryViewModel::class.java) -> {
                LibraryViewModel(libraryRepository) as T
            }
            modelClass.isAssignableFrom(QuestionnaireViewModel::class.java) -> {
                QuestionnaireViewModel(userPreferencesRepository) as T
            }
            modelClass.isAssignableFrom(SearchViewModel::class.java) -> {
                SearchViewModel(booksRepository) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class ${modelClass.name}")
        }
    }

    companion object {
        @Volatile
        private var instance: ViewModelFactory? = null

        fun getInstance(context: Context, savedStateHandle: SavedStateHandle = SavedStateHandle()): ViewModelFactory {
            return instance ?: synchronized(this) {
                instance ?: ViewModelFactory(
                    Injection.provideBooksRepository(context),
                    Injection.provideLibraryRepository(context),
                    Injection.provideUserPreferencesRepository(context),
                    savedStateHandle
                ).also { instance = it }
            }
        }
    }
}