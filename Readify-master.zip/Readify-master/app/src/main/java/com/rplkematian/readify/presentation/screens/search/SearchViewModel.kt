package com.rplkematian.readify.presentation.screens.search

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rplkematian.readify.domain.models.Book
import com.rplkematian.readify.domain.repository.BooksRepository
import com.rplkematian.readify.domain.usecase.SearchBooksUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

class SearchViewModel (
    private val booksRepository: BooksRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    // Common book genres
    private val genres = listOf(
        "Fiction", "Mystery", "Science Fiction", "Fantasy",
        "Romance", "Thriller", "Horror", "Biography",
        "History", "Science", "Philosophy", "Poetry"
    )

    init {
        _uiState.update { it.copy(genres = genres) }
        setupSearchQueryDebounce()
    }

    private suspend fun searchBooksUseCase(query: String, page: Int = 0): Result<List<Book>> {
        return if (query.isBlank()) {
            Result.success(emptyList())
        } else {
            booksRepository.searchBooks(query, page)
        }
    }

    @OptIn(FlowPreview::class)
    private fun setupSearchQueryDebounce() {
        _uiState
            .map { it.searchQuery }
            .debounce(500)
            .distinctUntilChanged()
            .filter { it.length >= 2 }
            .onEach { search(it) }
            .launchIn(viewModelScope)
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun onGenreSelected(genre: String) {
        viewModelScope.launch {
            search("subject:$genre")
        }
    }

    fun search(query: String = _uiState.value.searchQuery) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            try {
                searchBooksUseCase(query).fold(
                    onSuccess = { books ->
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                searchResults = books,
                                error = null
                            )
                        }
                        Log.d("Search books", "Success, $books")
                    },
                    onFailure = { exception ->
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                searchResults = emptyList(),
                                error = exception.message
                            )
                        }
                        Log.d("Search books", "Failed")
                    }
                )
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        searchResults = emptyList(),
                        error = e.message
                    )
                }
            }
        }
    }
}

data class SearchUiState(
    val searchQuery: String = "",
    val searchResults: List<Book> = emptyList(),
    val genres: List<String> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)