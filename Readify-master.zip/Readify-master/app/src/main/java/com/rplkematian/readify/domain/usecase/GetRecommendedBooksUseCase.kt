package com.rplkematian.readify.domain.usecase

import com.rplkematian.readify.domain.models.Book
import com.rplkematian.readify.domain.repository.BooksRepository
import javax.inject.Inject

class GetRecommendedBooksUseCase @Inject constructor(
    private val repository: BooksRepository
) {
    suspend operator fun invoke(preferences: Map<String, Any>): Result<List<Book>> {
        return repository.getRecommendedBooks(preferences)
    }
}