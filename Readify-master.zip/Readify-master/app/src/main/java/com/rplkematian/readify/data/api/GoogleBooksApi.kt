package com.rplkematian.readify.data.api

import com.rplkematian.readify.data.models.dto.BookDto
import com.rplkematian.readify.data.models.dto.GoogleBooksResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface GoogleBooksApi {
    @GET("volumes")
    suspend fun searchBooks(
        @Query("q") query: String,
        @Query("startIndex") startIndex: Int = 0,
        @Query("maxResults") maxResults: Int = 20,
        @Query("orderBy") orderBy: String = "relevance",
        @Query("filter") filter: String = "paid-ebooks",
        @Query("langRestrict") langRestrict: String = "en",
        @Query("printType") printType: String = "books",
        @Query("key") apiKey: String
    ): GoogleBooksResponse

    @GET("volumes/{volumeId}")
    suspend fun getBookDetails(
        @Path("volumeId") volumeId: String,
        @Query("key") apiKey: String
    ): BookDto
}