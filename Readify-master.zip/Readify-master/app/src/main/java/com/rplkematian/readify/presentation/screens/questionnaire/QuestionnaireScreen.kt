package com.rplkematian.readify.presentation.screens.questionnaire

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rplkematian.readify.domain.models.ReadingFrequency
import com.rplkematian.readify.utils.ViewModelFactory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuestionnaireScreen(
    onComplete: () -> Unit
) {
    var selectedGenres by remember { mutableStateOf(setOf<String>()) }
    var selectedFrequency by remember { mutableStateOf<ReadingFrequency?>(null) }
    var currentStep by remember { mutableStateOf(0) }
    val viewModel: QuestionnaireViewModel = viewModel(
        factory = ViewModelFactory.getInstance(
            LocalContext.current
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Setup Your Preferences") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Progress indicator
            LinearProgressIndicator(
                progress = { (currentStep + 1) / 2f },
                modifier = Modifier.fillMaxWidth()
            )

            // Step title
            Text(
                text = when (currentStep) {
                    0 -> "What genres do you enjoy reading?"
                    1 -> "How often do you read?"
                    else -> ""
                },
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(vertical = 16.dp)
            )

            // Step content
            when (currentStep) {
                0 -> {
                    // Genre selection
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(AVAILABLE_GENRES) { genre ->
                            FilterChip(
                                selected = genre in selectedGenres,
                                onClick = {
                                    selectedGenres = if (genre in selectedGenres) {
                                        selectedGenres - genre
                                    } else {
                                        selectedGenres + genre
                                    }
                                },
                                label = { Text(genre) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                1 -> {
                    // Reading frequency selection
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReadingFrequency.entries.forEach { frequency ->
                            Card(
                                onClick = { selectedFrequency = frequency },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = when (frequency) {
                                                ReadingFrequency.RARELY -> "Rarely"
                                                ReadingFrequency.OCCASIONALLY -> "Occasionally"
                                                ReadingFrequency.REGULARLY -> "Regularly"
                                                ReadingFrequency.FREQUENTLY -> "Frequently"
                                            },
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Text(
                                            text = when (frequency) {
                                                ReadingFrequency.RARELY -> "Few books per year"
                                                ReadingFrequency.OCCASIONALLY -> "1-2 books per month"
                                                ReadingFrequency.REGULARLY -> "1-2 books per week"
                                                ReadingFrequency.FREQUENTLY -> "More than 2 books per week"
                                            },
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (selectedFrequency == frequency) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Navigation buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (currentStep > 0) {
                    Button(
                        onClick = { currentStep-- },
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    ) {
                        Text("Back")
                    }
                }

                when (currentStep) {
                    0 -> {
                        Button(
                            onClick = { currentStep++ },
                            enabled = selectedGenres.isNotEmpty(),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Next")
                        }
                    }

                    1 -> {
                        Button(
                            onClick = {
                                viewModel.updateGenres(selectedGenres)
                                selectedFrequency?.let { viewModel.updateReadingFrequency(it) }
                                viewModel.savePreferences { onComplete() }
                            },
                            enabled = selectedFrequency != null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Complete")
                        }
                    }
                }
            }
        }
    }
}