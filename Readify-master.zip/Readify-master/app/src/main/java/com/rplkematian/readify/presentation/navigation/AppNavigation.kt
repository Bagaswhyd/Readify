package com.rplkematian.readify.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.google.gson.Gson
import com.rplkematian.readify.data.repository.UserPreferencesRepositoryImpl
import com.rplkematian.readify.presentation.screens.browse.BrowseScreen
import com.rplkematian.readify.presentation.screens.library.LibraryScreen
import com.rplkematian.readify.presentation.screens.search.SearchScreen
import com.rplkematian.readify.presentation.screens.bookdetail.BookDetailScreen
import com.rplkematian.readify.presentation.screens.questionnaire.QuestionnaireScreen
import com.rplkematian.readify.presentation.screens.questionnaire.QuestionnaireViewModel

@Composable
fun AppNavigation(
    navController: NavHostController,
    modifier: Modifier = Modifier,
    startDestination: String = Screen.Browse.route,
    shouldShowQuestionnaire: Boolean = false
) {
    NavHost(
        navController = navController,
        startDestination = if (shouldShowQuestionnaire) Screen.Questionnaire.route else startDestination,
        modifier = modifier
    ) {
        composable(Screen.Browse.route) {
            BrowseScreen(
                onBookClick = { bookId ->
                    navController.navigate(Screen.BookDetail.createRoute(bookId))
                }
            )
        }

        composable(Screen.Search.route) {
            SearchScreen(
                onBookClick = { bookId ->
                    navController.navigate(Screen.BookDetail.createRoute(bookId))
                }
            )
        }

        composable(Screen.Library.route) {
            LibraryScreen(
                onBookClick = { bookId ->
                    navController.navigate(Screen.BookDetail.createRoute(bookId))
                },
                onNavigateToSearch = {
                    navController.navigate(Screen.Search.route)
                }
            )
        }

        composable(
            route = Screen.BookDetail.route,
            arguments = listOf(
                navArgument("bookId") {
                    type = NavType.StringType
                    nullable = false
                }
            )
        ) { backStackEntry ->
            val bookId = backStackEntry.arguments?.getString("bookId")
            BookDetailScreen(
                onNavigateUp = {
                    navController.navigateUp()
                },
                onSimilarBookClick = { newBookId ->
                    navController.navigate(Screen.BookDetail.createRoute(newBookId)) {
                        popUpTo(Screen.BookDetail.route) {
                            inclusive = true
                        }
                    }
                },
                bookId ?: ""
            )
        }

        composable(Screen.Questionnaire.route) {
            QuestionnaireScreen(
                onComplete = {
                    // Navigate to browse and remove questionnaire from back stack
                    navController.navigate(Screen.Browse.route) {
                        popUpTo(Screen.Questionnaire.route) {
                            inclusive = true
                        }
                    }
                }
            )
        }
    }
}