package com.rplkematian.readify.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.rplkematian.readify.domain.models.BookLength
import com.rplkematian.readify.domain.models.ReadingFrequency
import com.rplkematian.readify.domain.models.UserPreferences
import com.rplkematian.readify.domain.repository.UserPreferencesRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "user_preferences")

@Singleton
class UserPreferencesRepositoryImpl (
    @ApplicationContext private val context: Context,
    private val gson: Gson
) : UserPreferencesRepository {

    private val dataStore: DataStore<Preferences> = context.dataStore

    private object PreferencesKeys {
        val FAVORITE_GENRES = stringPreferencesKey("favorite_genres")
        val READING_FREQUENCY = stringPreferencesKey("reading_frequency")
        val PREFERRED_LANGUAGES = stringPreferencesKey("preferred_languages")
        val PREFERRED_BOOK_LENGTH = stringPreferencesKey("preferred_book_length")
        val HAS_COMPLETED_QUESTIONNAIRE = booleanPreferencesKey("has_completed_questionnaire")
    }

    override val userPreferences: Flow<UserPreferences> = dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            UserPreferences(
                favoriteGenres = gson.fromJson(
                    preferences[PreferencesKeys.FAVORITE_GENRES] ?: "[]",
                    Array<String>::class.java
                ).toList(),
                readingFrequency = ReadingFrequency.valueOf(
                    preferences[PreferencesKeys.READING_FREQUENCY] ?: ReadingFrequency.OCCASIONALLY.name
                ),
                preferredLanguages = gson.fromJson(
                    preferences[PreferencesKeys.PREFERRED_LANGUAGES] ?: "[\"en\"]",
                    Array<String>::class.java
                ).toList(),
                preferredBookLength = BookLength.valueOf(
                    preferences[PreferencesKeys.PREFERRED_BOOK_LENGTH] ?: BookLength.MEDIUM.name
                ),
                hasCompletedQuestionnaire = preferences[PreferencesKeys.HAS_COMPLETED_QUESTIONNAIRE] ?: false
            )
        }

    override suspend fun updateUserPreferences(userPreferences: UserPreferences) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.FAVORITE_GENRES] = gson.toJson(userPreferences.favoriteGenres)
            preferences[PreferencesKeys.READING_FREQUENCY] = userPreferences.readingFrequency.name
            preferences[PreferencesKeys.PREFERRED_LANGUAGES] = gson.toJson(userPreferences.preferredLanguages)
            preferences[PreferencesKeys.PREFERRED_BOOK_LENGTH] = userPreferences.preferredBookLength.name
            preferences[PreferencesKeys.HAS_COMPLETED_QUESTIONNAIRE] = userPreferences.hasCompletedQuestionnaire
        }
    }
}