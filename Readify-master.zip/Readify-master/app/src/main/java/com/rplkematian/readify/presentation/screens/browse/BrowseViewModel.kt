package com.rplkematian.readify.presentation.screens.browse

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rplkematian.readify.domain.models.Book
import com.rplkematian.readify.domain.repository.BooksRepository
import com.rplkematian.readify.domain.repository.UserPreferencesRepository
import com.rplkematian.readify.domain.usecase.GetRecommendedBooksUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

class BrowseViewModel(
    private val booksRepository: BooksRepository,
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(BrowseUiState())
    val uiState: StateFlow<BrowseUiState> = _uiState.asStateFlow()

    init {
        loadRecommendations()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshing = true) }
            loadRecommendations(isRefresh = true)
        }
    }

    private suspend fun getRecommendedBooksUseCase(preferences: Map<String, Any>): Result<List<Book>> {
        return booksRepository.getRecommendedBooks(preferences)
    }

    private fun loadRecommendations(isRefresh: Boolean = false) {
        viewModelScope.launch {
            if (!isRefresh) {
                _uiState.update { it.copy(isLoading = true) }
            }

            try {
                // Get user preferences
                val userPrefs = userPreferencesRepository.userPreferences.first()

                val userPreferences = mapOf(
                    "favoriteGenres" to userPrefs.favoriteGenres,
                    "readingFrequency" to userPrefs.readingFrequency,
                    "preferredLanguages" to userPrefs.preferredLanguages,
                    "preferredBookLength" to userPrefs.preferredBookLength
                )

                val recommendationsResult = getRecommendedBooksUseCase(userPreferences)

                recommendationsResult.fold(
                    onSuccess = { books ->
                        _uiState.update { state ->
                            state.copy(
                                isLoading = false,
                                isRefreshing = false,
                                recommendations = createRecommendationSections(books, userPrefs.favoriteGenres),
                                error = null
                            )
                        }
                    },
                    onFailure = { exception ->
                        _uiState.update { state ->
                            state.copy(
                                isLoading = false,
                                isRefreshing = false,
                                error = exception.message
                            )
                        }
                    }
                )
            } catch (e: Exception) {
                _uiState.update { state ->
                    state.copy(
                        isLoading = false,
                        isRefreshing = false,
                        error = e.message
                    )
                }
            }
        }
    }

    private fun createRecommendationSections(books: List<Book>, userGenres: List<String>): List<RecommendationSection> {
        val sections = mutableListOf<RecommendationSection>()

        // Popular Books section
        val popularBooks = books.filter { it.rating != null }
            .sortedWith(
                compareByDescending<Book> { it.rating }
                    .thenByDescending { it.ratingCount }
            )
            .take(10)
        if (popularBooks.isNotEmpty()) {
            sections.add(RecommendationSection("Popular Books", popularBooks))
        }

        // New Releases
        val newReleases = books.filter { it.publishedDate?.contains("2024") == true }
            .take(10)
        if (newReleases.isNotEmpty()) {
            sections.add(RecommendationSection("New Releases", newReleases))
        }

        // Personalized Recommendations based on user's favorite genres
        userGenres.forEach { genre ->
            val genreBooks = books.filter { book ->
                book.categories.any { it.contains(genre, ignoreCase = true) }
            }.take(10)

            if (genreBooks.isNotEmpty()) {
                sections.add(RecommendationSection("Popular in $genre", genreBooks))
            }
        }

        return sections
    }

    fun retry() {
        loadRecommendations()
    }
}

data class BrowseUiState(
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val recommendations: List<RecommendationSection> = emptyList(),
    val error: String? = null
)

data class RecommendationSection(
    val title: String,
    val books: List<Book>
)