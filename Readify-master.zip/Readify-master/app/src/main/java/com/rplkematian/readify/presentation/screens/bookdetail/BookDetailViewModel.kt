package com.rplkematian.readify.presentation.screens.bookdetail

import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rplkematian.readify.domain.models.Book
import com.rplkematian.readify.domain.repository.BooksRepository
import com.rplkematian.readify.domain.repository.LibraryRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class BookDetailViewModel(
    private val booksRepository: BooksRepository,
    private val libraryRepository: LibraryRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val bookId: String? = savedStateHandle.get<String>("bookId")

    private val _uiState = MutableStateFlow(BookDetailUiState())
    val uiState: StateFlow<BookDetailUiState> = combine(
        _uiState,
        bookId?.let { libraryRepository.isBookInLibrary(it) } ?: flowOf(emptyList())
    ) { state, isInLibrary ->
        Log.d("BookDetailViewModel", "isInLibrary: $isInLibrary")
        state.copy(isInLibrary = isInLibrary.isNotEmpty())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = BookDetailUiState()
    )

    init {
        bookId?.let { loadBookDetails(it) }
    }

    fun isBookInLibrary(bookId: String): Boolean = runBlocking {
        libraryRepository.getBookById(bookId) != null
    }

    fun loadBookDetails(id: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            try {
                val bookResult = booksRepository.getBookDetails(id)
                bookResult.fold(
                    onSuccess = { book ->
                        _uiState.update { state ->
                            state.copy(
                                book = book,
                                isLoading = false,
                                error = null
                            )
                        }
                        loadSimilarBooks(book.categories)
                    },
                    onFailure = { exception ->
                        _uiState.update { state ->
                            state.copy(
                                isLoading = false,
                                error = exception.message
                            )
                        }
                    }
                )
            } catch (e: Exception) {
                _uiState.update { state ->
                    state.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    private fun loadSimilarBooks(categories: List<String>) {
        viewModelScope.launch {
            try {
                val similarBooksResult = booksRepository.getSimilarBooks(categories)
                similarBooksResult.fold(
                    onSuccess = { books ->
                        _uiState.update { state ->
                            state.copy(
                                similarBooks = books.filter { it.id != bookId }
                            )
                        }
                    },
                    onFailure = { /* Ignore failures for similar books */ }
                )
            } catch (e: Exception) {
                // Ignore failures for similar books
            }
        }
    }

    fun toggleLibraryStatus(book: Book,isInLibrary: Boolean) {
        viewModelScope.launch {
            if (isInLibrary) {
                libraryRepository.removeBook(book.id)
            } else {
                libraryRepository.addBook(book)
            }
        }
    }

    fun retry() {
        bookId?.let { loadBookDetails(it) }
    }
}

data class BookDetailUiState(
    val book: Book? = null,
    val similarBooks: List<Book> = emptyList(),
    val isLoading: Boolean = false,
    val isInLibrary: Boolean = false,
    val error: String? = null
)