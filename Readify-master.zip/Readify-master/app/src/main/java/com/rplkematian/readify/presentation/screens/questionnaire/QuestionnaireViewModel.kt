package com.rplkematian.readify.presentation.screens.questionnaire

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rplkematian.readify.domain.models.BookLength
import com.rplkematian.readify.domain.models.ReadingFrequency
import com.rplkematian.readify.domain.models.UserPreferences
import com.rplkematian.readify.domain.repository.UserPreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

class QuestionnaireViewModel(
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(QuestionnaireUiState())
    val uiState: StateFlow<QuestionnaireUiState> = _uiState.asStateFlow()

    fun updateGenres(genres: Set<String>) {
        _uiState.value = _uiState.value.copy(selectedGenres = genres)
    }

    fun updateReadingFrequency(frequency: ReadingFrequency) {
        _uiState.value = _uiState.value.copy(readingFrequency = frequency)
    }

    fun savePreferences(onComplete: () -> Unit) {
        viewModelScope.launch {
            val preferences = UserPreferences(
                favoriteGenres = _uiState.value.selectedGenres.toList(),
                readingFrequency = _uiState.value.readingFrequency ?: ReadingFrequency.OCCASIONALLY,
                preferredLanguages = listOf("en"),
                preferredBookLength = BookLength.MEDIUM,
                hasCompletedQuestionnaire = true  // Set this to true when completed
            )
            userPreferencesRepository.updateUserPreferences(preferences)
            onComplete()
        }
    }
}

data class QuestionnaireUiState(
    val selectedGenres: Set<String> = emptySet(),
    val readingFrequency: ReadingFrequency? = null
)