package com.rplkematian.readify.data.models.dto

import com.rplkematian.readify.domain.models.Book

fun BookDto.toBook(): Book {
    return Book(
        id = id,
        title = volumeInfo.title,
        authors = volumeInfo.authors ?: emptyList(),
        description = volumeInfo.description,
        coverUrl = volumeInfo.imageLinks?.thumbnail?.replace("http://", "https://"),
        categories = volumeInfo.categories ?: emptyList(),
        rating = volumeInfo.averageRating,
        ratingCount = volumeInfo.ratingsCount,
        pageCount = volumeInfo.pageCount,
        publishedDate = volumeInfo.publishedDate,
        publisher = volumeInfo.publisher,
        language = volumeInfo.language,
        buyLink = saleInfo?.buyLink,
        webReaderLink = accessInfo?.webReaderLink
    )
}