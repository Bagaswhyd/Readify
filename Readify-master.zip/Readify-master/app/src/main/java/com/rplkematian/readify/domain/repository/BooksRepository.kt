package com.rplkematian.readify.domain.repository

import com.rplkematian.readify.domain.models.Book
import kotlinx.coroutines.flow.Flow

interface BooksRepository {
    suspend fun searchBooks(query: String, page: Int): Result<List<Book>>
    suspend fun getBookDetails(bookId: String): Result<Book>
    suspend fun getSimilarBooks(categories: List<String>): Result<List<Book>>
    suspend fun getRecommendedBooks(userPreferences: Map<String, Any>): Result<List<Book>>
}