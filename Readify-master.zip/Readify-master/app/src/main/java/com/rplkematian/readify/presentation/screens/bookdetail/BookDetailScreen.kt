package com.rplkematian.readify.presentation.screens.bookdetail

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.bumptech.glide.integration.compose.placeholder
import com.rplkematian.readify.R
import com.rplkematian.readify.domain.models.Book
import com.rplkematian.readify.presentation.components.BookCard
import com.rplkematian.readify.utils.ViewModelFactory
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookDetailScreen(
    onNavigateUp: () -> Unit,
    onSimilarBookClick: (String) -> Unit,
    bookId: String
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()

    val viewModel: BookDetailViewModel = viewModel(
        factory = ViewModelFactory.getInstance(
            LocalContext.current,
            SavedStateHandle(mapOf("bookId" to bookId))
        )
    )

    val uiState by viewModel.uiState.collectAsState()
    val uriHandler = LocalUriHandler.current

    viewModel.loadBookDetails(bookId)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.book_details)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateUp) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.navigate_up)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { paddingValues ->
        when {
            uiState.isLoading -> {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    CircularProgressIndicator()
                }
            }

            uiState.error != null -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(16.dp)
                ) {
                    Text(
                        text = uiState.error ?: stringResource(R.string.error_loading_book),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = { viewModel.retry() },
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Text(stringResource(R.string.retry))
                    }
                }
            }

            else -> {
                uiState.book?.let { book ->
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                    ) {
                        item {
                            BookHeader(
                                book = book,
                                modifier = Modifier.padding(16.dp)
                            )
                        }

                        item {
                            ActionButtons(
                                book = book,
                                onBuyClick = { buyLink ->
                                    buyLink?.let { uriHandler.openUri(it) }
                                },
                                onReadClick = { webReaderLink ->
                                    webReaderLink?.let { uriHandler.openUri(it) }
                                },
                                modifier = Modifier.padding(horizontal = 16.dp),
                                viewModel = viewModel,
                                uiState
                            )
                        }

                        item {
                            BookDescription(
                                description = book.description,
                                modifier = Modifier.padding(16.dp)
                            )
                        }

                        item {
                            BookDetails(
                                book = book,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }

                        if (uiState.similarBooks.isNotEmpty()) {
                            item {
                                Text(
                                    text = stringResource(R.string.similar_books),
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                            item {
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    items(uiState.similarBooks) { similarBook ->
                                        BookCard(
                                            book = similarBook,
                                            onClick = { onSimilarBookClick(similarBook.id) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalGlideComposeApi::class)
@Composable
private fun BookHeader(
    book: Book,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.fillMaxWidth()
    ) {
        GlideImage(
            model = book.coverUrl,
            contentDescription = stringResource(R.string.book_cover_description, book.title),
            contentScale = ContentScale.FillHeight,
            modifier = Modifier.height(300.dp)
        )

        Text(
            text = book.title,
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 16.dp)
        )

        Text(
            text = book.authors.joinToString(", "),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp)
        )

        if (book.rating != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Star,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = String.format(Locale.getDefault(), "%.1f", book.rating),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(start = 4.dp)
                )
                book.ratingCount?.let { count ->
                    Text(
                        text = stringResource(R.string.rating_count, count),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionButtons(
    book: Book,
    onBuyClick: (String?) -> Unit,
    onReadClick: (String?) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: BookDetailViewModel,
    uiState: BookDetailUiState
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        /*FilledTonalButton(
            onClick = { onBuyClick(book.buyLink) },
            enabled = book.buyLink != null,
            modifier = Modifier.weight(1f)
        ) {
            Icon(Icons.Filled.ShoppingCart, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(text = "Purchase")
        }*/

        val isInLibraryButton = remember { mutableStateOf(viewModel.isBookInLibrary(book.id)) }
        val icon = remember {
            mutableStateOf(
                if (isInLibraryButton.value) {
                    Icons.Filled.Delete
                } else {
                    Icons.Filled.FavoriteBorder
                }
            )
        }
        val text = remember {
            mutableStateOf(
                if (isInLibraryButton.value) {
                    "Remove"
                } else {
                    "Favorite"
                }
            )
        }

        FilledTonalButton(
            onClick = { onReadClick(book.webReaderLink) },
            enabled = book.webReaderLink != null,
            modifier = Modifier.weight(1f)
        ) {
            Icon(Icons.Filled.Menu, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(
                text = if (book.webReaderLink != null) {
                    stringResource(R.string.read)
                } else {
                    stringResource(R.string.read)
                }
            )
        }

        FilledTonalButton(
            onClick = {
                if (isInLibraryButton.value) {
                    viewModel.toggleLibraryStatus(book, true)
                    icon.value = Icons.Filled.FavoriteBorder
                    text.value = "Favorite"
                    isInLibraryButton.value = false
                } else {
                    viewModel.toggleLibraryStatus(book, false)
                    icon.value = Icons.Filled.Favorite
                    text.value = "Remove"
                    isInLibraryButton.value = true
                }
            },
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                icon.value,
                contentDescription = null
            )
            Spacer(Modifier.width(8.dp))
            Text(text = text.value)
        }
    }
}

@Composable
private fun BookDescription(
    description: String?,
    modifier: Modifier = Modifier
) {
    if (!description.isNullOrBlank()) {
        Column(modifier = modifier) {
            Text(
                text = stringResource(R.string.description),
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun BookDetails(
    book: Book,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = stringResource(R.string.details),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        book.publisher?.let {
            DetailRow(
                label = stringResource(R.string.publisher),
                value = it
            )
        }

        book.publishedDate?.let {
            DetailRow(
                label = stringResource(R.string.published_date),
                value = it
            )
        }

        book.pageCount?.let {
            DetailRow(
                label = stringResource(R.string.page_count),
                value = it.toString()
            )
        }

        if (book.categories.isNotEmpty()) {
            DetailRow(
                label = stringResource(R.string.categories),
                value = book.categories.joinToString(", ")
            )
        }

        book.language?.let {
            DetailRow(
                label = stringResource(R.string.language),
                value = it.uppercase(Locale.getDefault())
            )
        }
    }
}

@Composable
private fun DetailRow(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(120.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}