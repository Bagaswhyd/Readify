package com.rplkematian.readify.data.repository

import com.rplkematian.readify.data.api.GoogleBooksApiClient
import com.rplkematian.readify.data.models.dto.toBook
import com.rplkematian.readify.domain.models.Book
import com.rplkematian.readify.domain.repository.BooksRepository
import javax.inject.Inject

class BooksRepositoryImpl(
    private val api: GoogleBooksApiClient
) : BooksRepository {
    override suspend fun searchBooks(query: String, page: Int): Result<List<Book>> = try {
        val response = api.searchBooks(
            query = query,
            startIndex = page * 20,
            orderBy = "relevance",
            filter = "paid-ebooks"
        )
        Result.success(response.items?.map { it.toBook() } ?: emptyList())
    } catch (e: Exception) {
        Result.failure(e)
    }

    override suspend fun getBookDetails(bookId: String): Result<Book> = try {
        val response = api.getBookDetails(bookId)
        Result.success(response.toBook())
    } catch (e: Exception) {
        Result.failure(e)
    }

    override suspend fun getSimilarBooks(categories: List<String>): Result<List<Book>> {
        return try {
            val query = categories.firstOrNull()?.let { "subject:$it" }
                ?: return Result.success(emptyList())

            val response = api.searchBooks(
                query = query,
                maxResults = 20,
                orderBy = "relevance",
                filter = "paid-ebooks"
            )
            Result.success(response.items?.map { it.toBook() } ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getRecommendedBooks(userPreferences: Map<String, Any>): Result<List<Book>> = try {
        val allBooks = mutableListOf<Book>()

        // Popular books section
        try {
            val popularResponse = api.searchPopularBooks(maxResults = 40)
            val popularBooks = popularResponse.items
                ?.map { it.toBook() }
                ?.filter { it.rating != null && it.ratingCount != null && it.ratingCount > 50 } // Lowered threshold
                ?.sortedWith(
                    compareByDescending<Book> { it.rating }
                        .thenByDescending { it.ratingCount }
                )
                ?: emptyList()
            allBooks.addAll(popularBooks)
        } catch (e: Exception) {
            // Continue
        }

        // Genre-specific books with better filtering
        val favoriteGenres = userPreferences["favoriteGenres"] as? List<String> ?: emptyList()
        favoriteGenres.forEach { genre ->
            try {
                // Make multiple searches with different parameters for each genre
                val genreBooks = mutableListOf<Book>()

                // Search by exact genre
                val exactGenreResponse = api.searchBooksByGenre(genre, maxResults = 20)
                genreBooks.addAll(exactGenreResponse.items?.map { it.toBook() } ?: emptyList())

                // Search with additional relevance terms
                val enhancedQuery = "subject:$genre bestseller"
                val enhancedResponse = api.searchBooks(
                    query = enhancedQuery,
                    maxResults = 20,
                    orderBy = "relevance",
                    filter = "paid-ebooks"
                )
                genreBooks.addAll(enhancedResponse.items?.map { it.toBook() } ?: emptyList())

                // Process and add genre books
                val processedGenreBooks = genreBooks
                    .distinctBy { it.id }
                    .filter { it.rating != null }
                    .sortedWith(
                        compareByDescending<Book> { it.rating }
                            .thenByDescending { it.ratingCount }
                    )
                    .take(15) // Ensure we have enough books per genre

                allBooks.addAll(processedGenreBooks)
            } catch (e: Exception) {
                // Continue with other genres
            }
        }

        // Get new releases
        try {
            val newReleasesResponse = api.searchNewReleases(maxResults = 40)
            val newBooks = newReleasesResponse.items
                ?.map { it.toBook() }
                ?.filter { it.publishedDate?.contains("2024") == true }
                ?: emptyList()
            allBooks.addAll(newBooks)
        } catch (e: Exception) {
            // Continue if new releases fail
        }

        // Remove duplicates and return
        Result.success(allBooks.distinctBy { it.id })
    } catch (e: Exception) {
        Result.failure(e)
    }
}