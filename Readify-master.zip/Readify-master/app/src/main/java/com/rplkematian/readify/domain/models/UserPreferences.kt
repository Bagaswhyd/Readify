package com.rplkematian.readify.domain.models

data class UserPreferences(
    val favoriteGenres: List<String> = emptyList(),
    val readingFrequency: ReadingFrequency = ReadingFrequency.OCCASIONALLY,
    val preferredLanguages: List<String> = listOf("en"),
    val preferredBookLength: BookLength = BookLength.MEDIUM,
    val hasCompletedQuestionnaire: Boolean = false
)

enum class ReadingFrequency {
    RARELY, // Few books per year
    OCCASIONALLY, // 1-2 books per month
    REGULARLY, // 1-2 books per week
    FREQUENTLY // More than 2 books per week
}

enum class BookLength {
    SHORT, // < 200 pages
    MEDIUM, // 200-400 pages
    LONG, // 400-600 pages
    VERY_LONG // > 600 pages
}