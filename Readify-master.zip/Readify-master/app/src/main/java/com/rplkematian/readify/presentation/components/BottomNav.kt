package com.rplkematian.readify.presentation.components

import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import com.rplkematian.readify.R
import com.rplkematian.readify.presentation.navigation.Screen

@Composable
fun BottomNav(navController: NavController) {
    if (shouldShowBottomBar(navController)) {
        val items = listOf(
            BottomNavItem(
                route = Screen.Browse.route,
                titleResId = R.string.browse,
                iconResId = R.drawable.ic_browse
            ),
            BottomNavItem(
                route = Screen.Search.route,
                titleResId = R.string.search,
                iconResId = R.drawable.ic_search
            ),
            BottomNavItem(
                route = Screen.Library.route,
                titleResId = R.string.library,
                iconResId = R.drawable.ic_library
            )
        )

        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentDestination = navBackStackEntry?.destination

        NavigationBar {
            items.forEach { item ->
                val selected = currentDestination?.hierarchy?.any {
                    it.route == item.route
                } ?: false

                NavigationBarItem(
                    icon = {
                        Icon(
                            painter = painterResource(id = item.iconResId),
                            contentDescription = stringResource(id = item.titleResId)
                        )
                    },
                    label = { Text(stringResource(id = item.titleResId)) },
                    selected = selected,
                    onClick = {
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    }
}

private data class BottomNavItem(
    val route: String,
    val titleResId: Int,
    val iconResId: Int
)

@Composable
private fun shouldShowBottomBar(navController: NavController): Boolean {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    return when {
        currentRoute?.startsWith(Screen.BookDetail.route.substringBefore("/")) == true -> false
        currentRoute == Screen.Questionnaire.route -> false
        else -> true
    }
}