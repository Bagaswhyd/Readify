package com.rplkematian.readify.data.repository

import com.rplkematian.readify.data.local.database.dao.LibraryDao
import com.rplkematian.readify.data.local.database.entity.LibraryBookEntity
import com.rplkematian.readify.domain.models.Book
import com.rplkematian.readify.domain.repository.LibraryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class LibraryRepositoryImpl (
    private val libraryDao: LibraryDao
) : LibraryRepository {

    override fun getAllBooks(): Flow<List<Book>> {
        return libraryDao.getAllBooks().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    override suspend fun addBook(book: Book) {
        libraryDao.insertBook(book.toEntity())
    }

    override suspend fun removeBook(bookId: String) {
        libraryDao.deleteBookById(bookId)
    }

    override fun isBookInLibrary(bookId: String): Flow<List<LibraryBookEntity>> {
        return libraryDao.isBookInLibrary(bookId)
    }

    override fun searchBooks(query: String): Flow<List<Book>> {
        return libraryDao.searchBooks(query).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    private fun LibraryBookEntity.toDomainModel(): Book {
        return Book(
            id = id,
            title = title,
            authors = authors,
            description = description,
            coverUrl = coverUrl,
            categories = categories,
            rating = rating,
            ratingCount = ratingCount,
            pageCount = pageCount,
            publishedDate = publishedDate,
            publisher = publisher,
            language = language,
            buyLink = buyLink,
            webReaderLink = webReaderLink
        )
    }

    private fun Book.toEntity(): LibraryBookEntity {
        return LibraryBookEntity(
            id = id,
            title = title,
            authors = authors,
            description = description,
            coverUrl = coverUrl,
            categories = categories,
            rating = rating,
            ratingCount = ratingCount,
            pageCount = pageCount,
            publishedDate = publishedDate,
            publisher = publisher,
            language = language,
            buyLink = buyLink,
            webReaderLink = webReaderLink
        )
    }

    override suspend fun getBookById(bookId: String): LibraryBookEntity? {
        return libraryDao.getBookById(bookId)
    }
}